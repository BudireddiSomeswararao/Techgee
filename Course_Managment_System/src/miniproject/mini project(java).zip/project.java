package miniproject;

import java.util.Scanner;

class courses {
	
	void details()
	{
		String Course[]= {"JAVA","Web Designing","Selenium"};
		System.out.println("Courses offered:");
		int size=Course.length;
		for(int i=0;i<size;i++)
		{
			System.out.println(Course[i]);
		}
		
	}
}
class Student{
	String StudentName;
	String StudentCourse;
	String date;
	Scanner sc=new Scanner(System.in);
	
	void values() {
		System.out.println("Enter your name:");
		StudentName=sc.nextLine();
		System.out.println("Enter your course:");
		StudentCourse=sc.nextLine();
		System.out.println("Enter your joining date:");
		date=sc.nextLine();
		
		
	}
}
public class project {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		courses s1=new courses();
		Student c=new Student();
		s1.details();
		c.values();
		System.out.println();
		System.out.println("details");
		System.out.println("StudentName:"+c.StudentName);
		System.out.println("StudentCourse:"+c.StudentCourse);
		System.out.println("Training Days:30");
		System.out.println("fees:50000");
		System.out.println("joining date:"+c.date);
	    
		
		

	}

}
